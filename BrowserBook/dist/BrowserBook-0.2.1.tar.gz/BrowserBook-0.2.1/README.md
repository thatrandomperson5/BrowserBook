# Browser Book
A web-browser backend for collecting resources.