__version__ = '0.1.3'

from browserbook.browserbookcode import brbook

from browserbook.ezbrbk import ezbook
print('Hello from BrowserBook!')
