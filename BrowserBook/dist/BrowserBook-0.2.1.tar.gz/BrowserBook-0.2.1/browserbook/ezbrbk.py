import browserbook.browserbookcode
class ezbook:
  pass